import SwiftUI

struct ChatView: View {
    @ObservedObject var networkService: NetworkService
    @State private var draftMessage = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                Text("Chat")
                    .font(.title2.bold())

                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(networkService.messages.indices, id: \.self) { index in
                            Text(networkService.messages[index])
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(.gray.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 8))

                HStack {
                    TextField("Type a message", text: $draftMessage)
                        .textFieldStyle(.roundedBorder)

                    Button("Send") {
                        networkService.send(draftMessage)
                        draftMessage = ""
                    }
                    .buttonStyle(.borderedProminent)
                }

                Button("Disconnect") {
                    networkService.goHome()
                }
                .buttonStyle(.bordered)
            }
            .padding()
        }
    }
}

#Preview {
    ChatView(networkService: NetworkService())
}
