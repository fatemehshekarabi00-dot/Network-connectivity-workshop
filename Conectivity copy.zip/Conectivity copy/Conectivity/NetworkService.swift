import Foundation
import Network
import Combine
import UIKit

final class NetworkService: ObservableObject {
    enum Screen {
        case home
        case hosting
        case join
        case chat
    }

    struct DiscoveredService: Identifiable {
        let id = UUID()
        let name: String
        let endpoint: NWEndpoint
    }

    @Published var screen: Screen = .home
    @Published var statusText: String = "Ready"
    @Published var discoveredServices: [DiscoveredService] = []
    @Published var messages: [String] = []

    private let serviceType = "_demo._tcp"
    private let queue = DispatchQueue(label: "NetworkServiceQueue")

    private var listener: NWListener?
    private var browser: NWBrowser?
    private var connection: NWConnection?
    private var receiveBuffer = ""
    private let debugLogPath = "/Users/seyedehshekarabi/Desktop/Conectivity/.cursor/debug-887efa.log"
    private let debugSessionId = "887efa"

    // MARK: - Host

    func startHosting() {
        // #region agent log
        logDebug(
            runId: "initial",
            hypothesisId: "H1",
            location: "NetworkService.swift:startHosting",
            message: "Host flow started",
            data: ["serviceType": serviceType]
        )
        // #endregion
        resetForNewFlow()
        screen = .hosting
        statusText = "Starting host..."

        do {
            let listener = try NWListener(using: .tcp, on: .any)
            listener.service = NWListener.Service(name: UIDevice.current.name, type: serviceType)

            // Accept the first incoming connection and move to chat.
            listener.newConnectionHandler = { [weak self] newConnection in
                self?.setupConnection(newConnection)
            }

            listener.stateUpdateHandler = { [weak self] state in
                DispatchQueue.main.async {
                    // #region agent log
                    self?.logDebug(
                        runId: "initial",
                        hypothesisId: "H2",
                        location: "NetworkService.swift:listener.stateUpdateHandler",
                        message: "Listener state updated",
                        data: ["state": String(describing: state)]
                    )
                    // #endregion
                    switch state {
                    case .ready:
                        self?.statusText = "Hosting..."
                    default:
                        self?.statusText = "Hosting state: \(state)"
                    }
                }
            }

            self.listener = listener
            listener.start(queue: queue)
        } catch {
            statusText = "Failed to start host"
            screen = .home
        }
    }

    // MARK: - Join

    func startBrowsing() {
        // #region agent log
        logDebug(
            runId: "initial",
            hypothesisId: "H3",
            location: "NetworkService.swift:startBrowsing",
            message: "Join flow started",
            data: ["serviceType": serviceType]
        )
        // #endregion
        resetForNewFlow()
        screen = .join
        statusText = "Searching..."

        let parameters = NWParameters.tcp
        let browser = NWBrowser(for: .bonjour(type: serviceType, domain: nil), using: parameters)

        // Update the list as Bonjour results change.
        browser.browseResultsChangedHandler = { [weak self] results, _ in
            let mapped = results.map { result -> DiscoveredService in
                let endpoint = result.endpoint
                let displayName = Self.displayName(for: endpoint)
                return DiscoveredService(name: displayName, endpoint: endpoint)
            }

            DispatchQueue.main.async {
                // #region agent log
                self?.logDebug(
                    runId: "initial",
                    hypothesisId: "H3",
                    location: "NetworkService.swift:browseResultsChangedHandler",
                    message: "Browse results changed",
                    data: ["resultCount": String(mapped.count)]
                )
                // #endregion
                self?.discoveredServices = mapped.sorted { $0.name < $1.name }
            }
        }

        browser.stateUpdateHandler = { [weak self] state in
            DispatchQueue.main.async {
                switch state {
                case .ready:
                    self?.statusText = "Looking for hosts..."
                default:
                    self?.statusText = "Browser state: \(state)"
                }
            }
        }

        self.browser = browser
        browser.start(queue: queue)
    }

    func connect(to service: DiscoveredService) {
        // #region agent log
        logDebug(
            runId: "initial",
            hypothesisId: "H4",
            location: "NetworkService.swift:connect",
            message: "Connect requested",
            data: ["serviceName": service.name]
        )
        // #endregion
        statusText = "Connecting to \(service.name)..."
        let connection = NWConnection(to: service.endpoint, using: .tcp)
        setupConnection(connection)
    }

    // MARK: - Chat

    func send(_ text: String) {
        let message = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !message.isEmpty else { return }

        let payload = Data((message + "\n").utf8)
        connection?.send(content: payload, completion: .contentProcessed { [weak self] _ in
            DispatchQueue.main.async {
                // #region agent log
                self?.logDebug(
                    runId: "initial",
                    hypothesisId: "H5",
                    location: "NetworkService.swift:send",
                    message: "Message send completion",
                    data: ["messageLength": String(message.count)]
                )
                // #endregion
                self?.messages.append("Me: \(message)")
            }
        })
    }

    func goHome() {
        listener?.cancel()
        browser?.cancel()
        connection?.cancel()

        listener = nil
        browser = nil
        connection = nil
        receiveBuffer = ""

        screen = .home
        discoveredServices = []
        messages = []
        statusText = "Ready"
    }

    // MARK: - Internal

    private func setupConnection(_ connection: NWConnection) {
        self.connection?.cancel()
        self.connection = connection

        connection.stateUpdateHandler = { [weak self] state in
            DispatchQueue.main.async {
                // #region agent log
                self?.logDebug(
                    runId: "initial",
                    hypothesisId: "H4",
                    location: "NetworkService.swift:connection.stateUpdateHandler",
                    message: "Connection state updated",
                    data: ["state": String(describing: state)]
                )
                // #endregion
                switch state {
                case .ready:
                    self?.screen = .chat
                    self?.statusText = "Connected"
                    self?.messages.removeAll()
                    self?.startReceiving()
                case .failed:
                    self?.statusText = "Connection failed"
                    self?.goHome()
                case .cancelled:
                    self?.goHome()
                default:
                    break
                }
            }
        }

        connection.start(queue: queue)
    }

    private func startReceiving() {
        connection?.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, _ in
            guard let self else { return }

            if let data, let chunk = String(data: data, encoding: .utf8) {
                // #region agent log
                self.logDebug(
                    runId: "initial",
                    hypothesisId: "H5",
                    location: "NetworkService.swift:startReceiving",
                    message: "Receive chunk",
                    data: [
                        "chunkLength": String(chunk.count),
                        "isComplete": String(isComplete)
                    ]
                )
                // #endregion
                self.receiveBuffer += chunk
                let lines = self.receiveBuffer.components(separatedBy: "\n")
                self.receiveBuffer = lines.last ?? ""

                let completeLines = lines.dropLast().filter { !$0.isEmpty }
                DispatchQueue.main.async {
                    for line in completeLines {
                        self.messages.append("Peer: \(line)")
                    }
                }
            }

            if isComplete {
                DispatchQueue.main.async {
                    self.goHome()
                }
                return
            }

            self.startReceiving()
        }
    }

    private func logDebug(
        runId: String,
        hypothesisId: String,
        location: String,
        message: String,
        data: [String: String]
    ) {
        let payload: [String: Any] = [
            "sessionId": debugSessionId,
            "runId": runId,
            "hypothesisId": hypothesisId,
            "location": location,
            "message": message,
            "data": data,
            "timestamp": Int(Date().timeIntervalSince1970 * 1000)
        ]

        guard let jsonData = try? JSONSerialization.data(withJSONObject: payload, options: []),
              let jsonLine = String(data: jsonData, encoding: .utf8) else {
            return
        }

        let line = jsonLine + "\n"
        guard let lineData = line.data(using: .utf8) else { return }

        if FileManager.default.fileExists(atPath: debugLogPath) {
            if let handle = try? FileHandle(forWritingTo: URL(fileURLWithPath: debugLogPath)) {
                defer { try? handle.close() }
                try? handle.seekToEnd()
                try? handle.write(contentsOf: lineData)
            }
        } else {
            try? lineData.write(to: URL(fileURLWithPath: debugLogPath), options: .atomic)
        }
    }

    private func resetForNewFlow() {
        listener?.cancel()
        browser?.cancel()
        connection?.cancel()

        listener = nil
        browser = nil
        connection = nil
        receiveBuffer = ""
        discoveredServices = []
        messages = []
    }

    private static func displayName(for endpoint: NWEndpoint) -> String {
        switch endpoint {
        case .service(let name, _, let domain, _):
            return domain.isEmpty ? name : "\(name) (\(domain))"
        case .hostPort(let host, let port):
            return "\(host):\(port)"
        default:
            return "Unknown service"
        }
    }
}
