import SwiftUI

struct HostingView: View {
    @ObservedObject var networkService: NetworkService

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                Text("Hosting...")
                    .font(.title2.bold())

                // Shows listener state updates from NetworkService.
                Text(networkService.statusText)
                    .foregroundStyle(.secondary)

                Button("Back") {
                    networkService.goHome()
                }
                .buttonStyle(.bordered)
            }
            .padding()
        }
    }
}

#Preview {
    HostingView(networkService: NetworkService())
}
