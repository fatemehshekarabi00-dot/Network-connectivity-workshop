//
//  ConectivityApp.swift
//  Conectivity
//
//  Created by Fatima on 13/04/26.
//

import SwiftUI

@main
struct ConectivityApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
