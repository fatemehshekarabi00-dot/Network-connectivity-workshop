import SwiftUI

struct HomeView: View {
    @ObservedObject var networkService: NetworkService

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Local Network Demo")
                    .font(.title2.bold())

                Button("Host") {
                    networkService.startHosting()
                }
                .buttonStyle(.borderedProminent)

                Button("Join") {
                    networkService.startBrowsing()
                }
                .buttonStyle(.bordered)
            }
            .padding()
        }
    }
}

#Preview {
    HomeView(networkService: NetworkService())
}
