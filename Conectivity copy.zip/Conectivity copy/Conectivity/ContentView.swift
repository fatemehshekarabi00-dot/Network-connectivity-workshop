//
//  ContentView.swift
//  Conectivity
//
//  Created by Fatima on 13/04/26.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var networkService = NetworkService()

    var body: some View {
        Group {
            switch networkService.screen {
            case .home:
                HomeView(networkService: networkService)
            case .hosting:
                HostingView(networkService: networkService)
            case .join:
                JoinView(networkService: networkService)
            case .chat:
                ChatView(networkService: networkService)
            }
        }
    }
}

#Preview {
    ContentView()
}
