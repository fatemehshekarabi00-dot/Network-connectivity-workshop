import SwiftUI

struct JoinView: View {
    @ObservedObject var networkService: NetworkService

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                Text("Available Hosts")
                    .font(.title2.bold())

                Text(networkService.statusText)
                    .foregroundStyle(.secondary)

                List(networkService.discoveredServices) { service in
                    Button(service.name) {
                        networkService.connect(to: service)
                    }
                }

                Button("Back") {
                    networkService.goHome()
                }
                .buttonStyle(.bordered)
            }
            .padding(.top)
        }
    }
}

#Preview {
    JoinView(networkService: NetworkService())
}
